/*----------------------------------------------------------------------------*/
/* Copyright (c) FIRST 2008. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package org.usfirst.frc0;

import edu.wpi.first.wpilibj.Joystick.ButtonType;
import edu.wpi.first.wpilibj.SimpleRobot;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.RobotDrive;
import edu.wpi.first.wpilibj.Timer;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the SimpleRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class ASimpleJavaBot extends SimpleRobot
{
	public RobotDrive robotDrive;
	public Joystick joystickL;
	public Joystick joystickR;
	
	protected void robotInit() {
		robotDrive = new RobotDrive(1,2);
		robotDrive.setSafetyEnabled(true);
		joystickL = new Joystick(1);
		joystickR = new Joystick(2);
		
	}
	
	/**
	 * This function is called once each time the robot enters autonomous mode.
	 */
	public void autonomous() {
		while(isAutonomous() && isEnabled())
		{
		}
	}

	/**
	 * This function is called once each time the robot enters operator control.
	 */
	public void operatorControl() {
		while(isOperatorControl() && isEnabled())
		{
			robotDrive.tankDrive(joystickL, joystickR);
			if (joystickR.getButton(ButtonType.kTrigger))
			{
				// TODO shoot
			}
			Timer.delay(0.010);
		}
	}
}
